@echo off
rem Startet den LaTeX-Projekt-Assistenten unter Windows.
cd /d "%~dp0"
where pyw >nul 2>nul && (start "" pyw latex_projekt_assistent.pyw & exit /b)
where pythonw >nul 2>nul && (start "" pythonw latex_projekt_assistent.pyw & exit /b)
echo Python wurde nicht gefunden. Bitte Python von python.org installieren (siehe Anleitung).
pause
