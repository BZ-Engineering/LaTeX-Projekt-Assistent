#!/bin/bash
# Startet den LaTeX-Projekt-Assistenten unter macOS (Doppelklick im Finder).
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  osascript -e 'display alert "Python 3 fehlt" message "Bitte Python von python.org installieren (siehe Anleitung)."'
  exit 1
fi
python3 latex_projekt_assistent.pyw
